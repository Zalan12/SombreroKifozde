﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sombrero_kifőzde
{
    internal class Program
    {
        static List<Etel> etelLista = new List<Etel>();
        static List<Ital> italLista = new List<Ital>();

        // Minimál, konkrét ital típusok (az alap osztályok absztraktak, de nincs bennük absztrakt tag)
        private class EgyszeruUdito : UditoItal
        {
            public EgyszeruUdito(string nev, int ar, bool szensav) : base(nev, ar, szensav) { }
            public override string ToString() => $"{Nev} | {Ar} Ft | Szénsavas: {(Szensav ? "igen" : "nem")}";
        }
        private class EgyszeruAlkoholos : AlkoholosItal
        {
            public EgyszeruAlkoholos(string nev, int ar, double alkohol) : base(nev, ar, alkohol) { }
            public override string ToString() => $"{Nev} | {Ar} Ft | Alkohol: {Alkohol_tartalom.ToString(CultureInfo.InvariantCulture)}%";
        }

        private class VasarlasTetel
        {
            public string Nev { get; set; }
            public int Ar { get; set; }
            public string Kategoria { get; set; }
        }

        private class KosarElem
        {
            public int GlobalId { get; set; }
            public VasarlasTetel Tetel { get; set; }
            public int Db { get; set; }
        }
        static void Main(string[] args)
        {

            VonalDisz(12);


            Szunet(1);
            etlapCim();
            
            Induljmeg();


        }

        private static void etlapCim()
        {
            Console.WriteLine("EEEEEEEEEEEEEEEEEEEEEE         tttt          lllllll");
            Console.WriteLine("E::::::::::::::::::::E      ttt:::t          l:::::l");
            Console.WriteLine("E::::::::::::::::::::E      t:::::t          l:::::l");
            Console.WriteLine("E::::::::::::::::::::E      t:::::t          l:::::l");
            Console.WriteLine("EE::::::EEEEEEEEE::::E      t:::::t          l:::::l");
            Console.WriteLine("  E:::::E       EEEEEEttttttt:::::ttttttt     l::::l   aaaaaaaaaaaaa  ppppp   ppppppppp");
            Console.WriteLine("  E:::::E             t:::::::::::::::::t     l::::l   a::::::::::::a p::::ppp:::::::::p  ");
            Console.WriteLine("  E::::::EEEEEEEEEE   t:::::::::::::::::t     l::::l   aaaaaaaaa:::::ap:::::::::::::::::p ");
            Console.WriteLine("  E:::::::::::::::E   tttttt:::::::tttttt     l::::l            a::::app::::::ppppp::::::p");
            Console.WriteLine("  E:::::::::::::::E         t:::::t           l::::l     aaaaaaa:::::a p:::::p     p:::::p");
            Console.WriteLine("  E::::::EEEEEEEEEE         t:::::t           l::::l   aa::::::::::::a p:::::p     p:::::p");
            Console.WriteLine("  E:::::E                   t:::::t           l::::l  a::::aaaa::::::a p:::::p     p:::::p");
            Console.WriteLine("  E:::::E       EEEEEE      t:::::t    tttttt l::::l a::::a    a:::::a p:::::p    p::::::p");
            Console.WriteLine("EE::::::EEEEEEEE:::::E      t::::::tttt:::::tl::::::la::::a    a:::::a p:::::ppppp:::::::p ");
            Console.WriteLine("E::::::::::::::::::::E      tt::::::::::::::tl::::::la:::::aaaa::::::a p::::::::::::::::p  ");
            Console.WriteLine("EEEEEEEEEEEEEEEEEEEEEE          ttttttttttt  llllllll  aaaaaaaaaa  aaaap::::::pppppppp ");
            Console.WriteLine("                                                                       p:::::p        ");
            Console.WriteLine("                                                                       p:::::p        ");
            Console.WriteLine("                                                                      p:::::::p        ");
            Console.WriteLine("                                                                      p:::::::p        ");
            Console.WriteLine("                                                                      p:::::::p        ");
            Console.WriteLine("                                                                      ppppppppp        ");
        }

        private static void Induljmeg()
        {
            //Ez a függvény indítja el az egész programot
            try
            {
                int budzse = PenzBekerEsEllenoriz();
                PenzKiiras(budzse);

                // Étlap beolvasása + kiírása
                LapKezeles(0);
                for (int i = 0; i < etelLista.Count; i++)
                {
                    VonalDisz(3);
                    Console.WriteLine("\n" + "ID:" + (i + 1) + "\n" + etelLista[i].ToString());
                    VonalDisz(3);
                }

                // Itallap beolvasása + kiírása (ha van)
                LapKezeles(1);
                if (italLista.Count > 0)
                {
                    Szunet(1);
                    VonalDisz(12);
                    Console.WriteLine("\nITALLAP");
                    VonalDisz(12);
                    for (int i = 0; i < italLista.Count; i++)
                    {
                        int globalId = etelLista.Count + i + 1;
                        VonalDisz(3);
                        Console.WriteLine("\n" + "ID:" + globalId + "\n" + italLista[i].ToString());
                        VonalDisz(3);
                    }
                }

                // Rendelés indítása
                RendelestKezel(budzse);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Annyira nem mély.");
            }
        }

        private static int PenzBekerEsEllenoriz()
        {
            while (true)
            {
                string be = PenzBeker();
                if (int.TryParse(be, out int budzse) && budzse >= 0)
                {
                    return budzse;
                }

                Console.WriteLine("Hibás összeg. Kérlek csak egy egész számot írj be (pl. 2000).\n");
            }
        }

        private static void RendelestKezel(int kezdoBudzse)
        {
            int maradek = kezdoBudzse;
            List<KosarElem> kosar = new List<KosarElem>();
            Stack<KosarElem> undo = new Stack<KosarElem>();

            Szunet(1);
            VonalDisz(2);
            Console.WriteLine("\n -> Rendelés: írd be az ID-kat vesszővel elválasztva (pl. 1,3,5).\n -> Mennyiség: 3x2 vagy 3*2 (ID x DB).\n -> Parancsok: V=Vége, K=Kosár, H=Help, U=Undo, C=Kosár ürítése, X <id>=1 db törlés");
            VonalDisz(2);
            Console.WriteLine();

            while (true)
            {
                Console.Write($" -> Maradék keret: {maradek} Ft | Bevitel/parancs: ");
                string sor = (Console.ReadLine() ?? string.Empty).Trim();

                if (string.IsNullOrWhiteSpace(sor))
                {
                    Console.WriteLine("Nem írtál be semmit.");
                    continue;
                }

                // Parancsok
                if (string.Equals(sor, "V", StringComparison.OrdinalIgnoreCase))
                {
                    RendelesKiirasa(kosar, kezdoBudzse, maradek);
                    Console.WriteLine("\nNyomj Entert a kilépéshez...");
                    Console.ReadLine();
                    return;
                }
                if (string.Equals(sor, "H", StringComparison.OrdinalIgnoreCase))
                {
                    PrintHelp();
                    continue;
                }
                if (string.Equals(sor, "K", StringComparison.OrdinalIgnoreCase))
                {
                    PrintKosar(kosar, kezdoBudzse, maradek);
                    continue;
                }
                if (string.Equals(sor, "U", StringComparison.OrdinalIgnoreCase))
                {
                    if (undo.Count == 0)
                    {
                        Console.WriteLine("Nincs mit visszavonni.");
                        continue;
                    }
                    var last = undo.Pop();
                    KosarElem existing = kosar.FirstOrDefault(x => x.GlobalId == last.GlobalId);
                    if (existing != null)
                    {
                        existing.Db -= last.Db;
                        if (existing.Db <= 0) kosar.Remove(existing);
                        maradek += last.Tetel.Ar * last.Db;
                        Console.WriteLine($"Visszavonva: {last.Tetel.Nev} x{last.Db}");
                    }
                    continue;
                }
                if (string.Equals(sor, "C", StringComparison.OrdinalIgnoreCase))
                {
                    kosar.Clear();
                    undo.Clear();
                    maradek = kezdoBudzse;
                    Console.WriteLine("Kosár ürítve.");
                    continue;
                }
                if (sor.StartsWith("X", StringComparison.OrdinalIgnoreCase))
                {
                    // X 3 -> 1 db törlés az adott ID-ból
                    string rest = sor.Substring(1).Trim();
                    if (!int.TryParse(rest, out int rid))
                    {
                        Console.WriteLine("Használat: X <id>  (példa: X 3)");
                        continue;
                    }
                    if (TryRemoveOne(kosar, rid, ref maradek))
                    {
                        Console.WriteLine($"Törölve 1 db az alábbi ID-ból: {rid}");
                    }
                    else
                    {
                        Console.WriteLine("Nincs ilyen tétel a kosárban.");
                    }
                    continue;
                }

                // Normál rendelés sor (ID-k, esetleg mennyiséggel)
                string[] darabok = sor.Split(',');
                foreach (var d in darabok)
                {
                    string token = d.Trim();
                    if (string.IsNullOrWhiteSpace(token)) continue;

                    if (!TryParseIdAndQty(token, out int id, out int qty))
                    {
                        Console.WriteLine($"  - '{token}' nem érvényes. Példa: 3 vagy 3x2");
                        continue;
                    }

                    int maxId = etelLista.Count + italLista.Count;
                    if (id < 1 || id > maxId)
                    {
                        Console.WriteLine($"  - Nincs ilyen ID: {id}.");
                        continue;
                    }

                    VasarlasTetel valasztott = GetTetelByGlobalId(id);
                    if (valasztott == null)
                    {
                        Console.WriteLine($"  - Nincs ilyen ID: {id}.");
                        continue;
                    }

                    if (qty <= 0) qty = 1;

                    int maxVeheto = valasztott.Ar == 0 ? qty : Math.Min(qty, maradek / valasztott.Ar);
                    if (maxVeheto <= 0)
                    {
                        Console.WriteLine($"  - {valasztott.Nev} ({valasztott.Ar} Ft) nem fér bele a maradék keretbe.");
                        continue;
                    }
                    if (maxVeheto < qty)
                    {
                        Console.WriteLine($"  ! Csak {maxVeheto} db fér bele ebből: {valasztott.Nev}");
                    }

                    AddToKosar(kosar, id, valasztott, maxVeheto);
                    undo.Push(new KosarElem { GlobalId = id, Tetel = valasztott, Db = maxVeheto });
                    maradek -= valasztott.Ar * maxVeheto;
                    Console.WriteLine($"  + Hozzáadva: {valasztott.Kategoria} - {valasztott.Nev} x{maxVeheto} ({valasztott.Ar} Ft/db)");
                }
            }
        }

        private static void RendelesKiirasa(List<KosarElem> kosar, int kezdoBudzse, int maradek)
        {
            Szunet(1);
            VonalDisz(3);
            Console.WriteLine("\nMEGVÁSÁROLT TERMÉKEK");
            VonalDisz(3);
            Console.WriteLine();

            if (kosar.Count == 0)
            {
                Console.WriteLine("Nem választottál semmit.");
            }
            else
            {
                // Blokkosított blokk: Ételek, majd Italok
                var etelek = kosar.Where(x => x.Tetel.Kategoria == "Étel").ToList();
                var italok = kosar.Where(x => x.Tetel.Kategoria == "Ital").ToList();

                if (etelek.Count > 0)
                {
                    Console.WriteLine("ÉTELEK:");
                    foreach (var e in etelek.OrderBy(x => x.GlobalId))
                    {
                        Console.WriteLine($" - ID:{e.GlobalId} | {e.Tetel.Nev} x{e.Db} | {e.Tetel.Ar} Ft/db | {e.Tetel.Ar * e.Db} Ft");
                    }
                    Console.WriteLine();
                }

                if (italok.Count > 0)
                {
                    Console.WriteLine("ITALOK:");
                    foreach (var i in italok.OrderBy(x => x.GlobalId))
                    {
                        Console.WriteLine($" - ID:{i.GlobalId} | {i.Tetel.Nev} x{i.Db} | {i.Tetel.Ar} Ft/db | {i.Tetel.Ar * i.Db} Ft");
                    }
                    Console.WriteLine();
                }

                int etelOssz = etelek.Sum(x => x.Tetel.Ar * x.Db);
                int italOssz = italok.Sum(x => x.Tetel.Ar * x.Db);
                if (etelek.Count > 0 && italok.Count > 0)
                {
                    Console.WriteLine($"Részösszeg (Étel): {etelOssz} Ft");
                    Console.WriteLine($"Részösszeg (Ital): {italOssz} Ft");
                }
            }

            int osszes = kezdoBudzse - maradek;
            Console.WriteLine($"\nÖsszesen: {osszes} Ft");
            Console.WriteLine($"Maradék: {maradek} Ft");
        }

        private static void PrintHelp()
        {
            VonalDisz(2);
            Console.WriteLine("\nPARANCSOK / TIPPEK");
            VonalDisz(2);
            Console.WriteLine("\n - ID-k vesszővel: 1,3,5");
            Console.WriteLine(" - Mennyiség: 3x2 vagy 3*2 (ID x DB)");
            Console.WriteLine(" - K : kosár megtekintése");
            Console.WriteLine(" - U : utolsó hozzáadás visszavonása");
            Console.WriteLine(" - X <id> : 1 db törlése a kosárból (pl. X 3)");
            Console.WriteLine(" - C : kosár ürítése");
            Console.WriteLine(" - V : véglegesítés és kilépés");
            Console.WriteLine();
        }

        private static void PrintKosar(List<KosarElem> kosar, int kezdoBudzse, int maradek)
        {
            VonalDisz(2);
            Console.WriteLine("\nKOSÁR");
            VonalDisz(2);
            Console.WriteLine();

            if (kosar.Count == 0)
            {
                Console.WriteLine("A kosár üres.");
            }
            else
            {
                foreach (var e in kosar.OrderBy(x => x.Tetel.Kategoria).ThenBy(x => x.GlobalId))
                {
                    Console.WriteLine($" - {e.Tetel.Kategoria} | ID:{e.GlobalId} | {e.Tetel.Nev} x{e.Db} | {e.Tetel.Ar * e.Db} Ft");
                }
            }

            int osszes = kezdoBudzse - maradek;
            Console.WriteLine($"\nÖsszesen eddig: {osszes} Ft | Maradék: {maradek} Ft");
            Console.WriteLine();
        }

        private static bool TryParseIdAndQty(string token, out int id, out int qty)
        {
            id = 0;
            qty = 1;

            // elfogadjuk: 3, 3x2, 3*2, 3 x 2
            string t = token.Replace(" ", string.Empty);
            char[] sep = new[] { 'x', 'X', '*'};
            int idx = t.IndexOfAny(sep);
            if (idx < 0)
            {
                return int.TryParse(t, out id);
            }

            string left = t.Substring(0, idx);
            string right = t.Substring(idx + 1);
            if (!int.TryParse(left, out id)) return false;
            if (!int.TryParse(right, out qty)) qty = 1;
            return true;
        }

        private static void AddToKosar(List<KosarElem> kosar, int id, VasarlasTetel tetel, int db)
        {
            KosarElem existing = kosar.FirstOrDefault(x => x.GlobalId == id);
            if (existing == null)
            {
                kosar.Add(new KosarElem { GlobalId = id, Tetel = tetel, Db = db });
            }
            else
            {
                existing.Db += db;
            }
        }

        private static bool TryRemoveOne(List<KosarElem> kosar, int id, ref int maradek)
        {
            KosarElem existing = kosar.FirstOrDefault(x => x.GlobalId == id);
            if (existing == null) return false;
            existing.Db -= 1;
            maradek += existing.Tetel.Ar;
            if (existing.Db <= 0) kosar.Remove(existing);
            return true;
        }

        private static void LapKezeles(int v)
        {

            //Ez a függvény kezeli az étlapot, itallapot illetve a rendeléseket switch case-el

            switch (v)
            {
                case 0:
                    string etlapPath = KeresdMegFajlt("etlap.txt");
                    if (etlapPath == null)
                        throw new FileNotFoundException("Nem találom az etlap.txt fájlt. Tedd a futtatható mellé, vagy a projekt mappába.");

                    string[] etlap= File.ReadAllLines(etlapPath);
                    for (int i = 1; i < etlap.Length; i++) 
                    {
                        string[] etel = etlap[i].Split(';');
                        if (etel[1] == "csirke") 
                        {
                            CsirkesEtel csirkesEtel = new CsirkesEtel(etel[0], etel[3], Convert.ToInt32(etel[2]), etel[1]);
                            etelLista.Add(csirkesEtel);
                        }
                        else if (etel[1] == "disznó")
                        {
                            DisznosEtel disznoEtel = new DisznosEtel(etel[0], etel[3], Convert.ToInt32(etel[2]), etel[1]);
                            etelLista.Add(disznoEtel);
                        }
                        else if (etel[1] == "Húsmentes")
                        {
                            Husmentes HmentesEtel = new Husmentes(etel[0], etel[3], Convert.ToInt32(etel[2]),etel[1]);
                            etelLista.Add (HmentesEtel);
                        }
                        else
                        {
                            Console.WriteLine("Van egy kivételes paca is");
                        }
                    }
                    
                    break;
                case 1:
                    // Itallap (ha létezik). Formátum többféle lehet, a kód rugalmas:
                    // pl. Nev;tipus;ar;extra
                    // tipus: "üdítő" -> extra: szénsavas (igen/nem/true/false/1/0)
                    // tipus: "alkoholos" -> extra: alkohol % (pl 5,0 vagy 5.0)
                    string itallapPath = KeresdMegFajlt("itallap.txt");
                    if (itallapPath == null)
                    {
                        // Nem kötelező fájl
                        return;
                    }

                    string[] itallap = File.ReadAllLines(itallapPath);
                    for (int i = 1; i < itallap.Length; i++)
                    {
                        string line = itallap[i].Trim();
                        if (string.IsNullOrWhiteSpace(line)) continue;

                        string[] ital = line.Split(';');
                        if (ital.Length < 3) continue;

                        string nev = ital[0];
                        string tipus = ital[1];
                        if (!int.TryParse(ital[2], out int ar)) continue;

                        string extra = ital.Length >= 4 ? ital[3] : string.Empty;

                        if (tipus.Equals("üdítő", StringComparison.OrdinalIgnoreCase) ||
                            tipus.Equals("udito", StringComparison.OrdinalIgnoreCase))
                        {
                            bool szensav = ExtraBool(extra);
                            italLista.Add(new EgyszeruUdito(nev, ar, szensav));
                        }
                        else if (tipus.Equals("alkoholos", StringComparison.OrdinalIgnoreCase))
                        {
                            double alkohol = ExtraDouble(extra);
                            italLista.Add(new EgyszeruAlkoholos(nev, ar, alkohol));
                        }
                        else
                        {
                            // Ismeretlen típus: próbáljuk üdítőként (szénsav nélkül)
                            italLista.Add(new EgyszeruUdito(nev, ar, false));
                        }
                    }
                    break;
            }
        }

        private static VasarlasTetel GetTetelByGlobalId(int id)
        {
            // 1..etelLista.Count => étel
            if (id >= 1 && id <= etelLista.Count)
            {
                Etel e = etelLista[id - 1];
                return new VasarlasTetel { Nev = e.Nev, Ar = e.Ar, Kategoria = "Étel" };
            }

            // továbbiak => ital
            int italIndex = id - etelLista.Count - 1;
            if (italIndex >= 0 && italIndex < italLista.Count)
            {
                Ital i = italLista[italIndex];
                return new VasarlasTetel { Nev = i.Nev, Ar = i.Ar, Kategoria = "Ital" };
            }

            return null;
        }

        private static string KeresdMegFajlt(string fajlNev)
        {
            // 1) aktuális munkakönyvtár
            if (File.Exists(fajlNev)) return Path.GetFullPath(fajlNev);

            // 2) exe mappa
            try
            {
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string p = Path.Combine(baseDir, fajlNev);
                if (File.Exists(p)) return p;

                // 3) pár szinttel feljebb (pl. bin\Debug\ -> projekt mappa)
                DirectoryInfo di = new DirectoryInfo(baseDir);
                for (int i = 0; i < 6 && di != null; i++)
                {
                    p = Path.Combine(di.FullName, fajlNev);
                    if (File.Exists(p)) return p;
                    di = di.Parent;
                }
            }
            catch { }

            return null;
        }

        private static bool ExtraBool(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim().ToLowerInvariant();
            return s == "1" || s == "true" || s == "igen" || s == "i" || s == "y" || s == "yes";
        }

        private static double ExtraDouble(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return 0;
            s = s.Trim();
            // elfogadjuk a vesszős és pontos tizedest is
            if (double.TryParse(s, NumberStyles.Any, new CultureInfo("hu-HU"), out double d)) return d;
            if (double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out d)) return d;
            return 0;
        }

        private static void PenzKiiras(double budzse)
            
        {
            //Ez a függvény fogja kiíratni a felhasználó által megadott büdzsét
            VonalDisz(1);
            Console.WriteLine(" Büdzsé : " + budzse);
            
        }

        private static void Szunet(int v)
        {

            //Ez a függvény csak egy szünetet csinál a konzolon
            for (int i = 0; i < v; i++)
            {
                Console.WriteLine("\n");
            }
        }

        private static string PenzBeker()
        {

            //Ez a függvény kéri be a felhasználótól a büdzsét
            VonalDisz(2);
            Console.WriteLine("\n -> Kérlek add meg mennyi pénzt szeretnél ma elkölteni? Számmal, elválasztás nélkül");
            VonalDisz(2);
            Console.WriteLine();
            Console.Write(" -> ");
            return Console.ReadLine();
        }

        private static void VonalDisz(int v)
        {

            //Ez a függvény vonaldíszítést csinál a konzolon
            for (int i = 0; i < v; i++)
            {
                Console.Write("----------");
            }

        }
    }
}
